package com.Project.TrainReservation.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Project.TrainReservation.model.Passenger;

@Repository
public interface PassengerRepository extends CrudRepository<Passenger, Integer> {

}
