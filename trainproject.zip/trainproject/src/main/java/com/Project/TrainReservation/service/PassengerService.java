package com.Project.TrainReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.Project.TrainReservation.model.Passenger;
import com.Project.TrainReservation.model.User;
import com.Project.TrainReservation.repository.PassengerRepository;
import com.Project.TrainReservation.repository.UserRepository;

@Component
public class PassengerService {
	
	@Autowired
	private PassengerRepository passengerRepository;
	
	public List<Passenger> getAllPassengers()
	{
		List<Passenger> list = (List<Passenger>)this.passengerRepository.findAll();
		return list;
	}

}
